# Proyecto Sabor & Sazón - UNAD

Este proyecto contiene una versión web del documento de la Fase 2 de Estructura de Datos.

## Archivos

- `index.html`: página principal.
- `style.css`: estilos visuales.

## Para probarlo en Visual Studio Code

1. Abre esta carpeta en Visual Studio Code.
2. Abre `index.html`.
3. Instala la extensión **Live Server**.
4. Haz clic derecho sobre `index.html`.
5. Selecciona **Open with Live Server**.

## Para publicar y obtener un enlace para el profesor

Sube `index.html` y `style.css` a un repositorio de GitHub y activa GitHub Pages desde:

Settings → Pages → Deploy from a branch → main → /(root) → Save.

El enlace público tendrá una forma similar a:

https://TU-USUARIO.github.io/NOMBRE-DEL-REPOSITORIO/
